ids = ["111111111", "222222222"]


class DroneAgent:
    def __init__(self, n, m):
        self.mode = 'train'  # do not change this!
        # your code here

    def select_action(self, obs0):
        # your code here
        raise NotImplemented

    def train(self):
        self.mode = 'train'  # do not change this!

    def eval(self):
        self.mode = 'eval'  # do not change this!

    def update(self, obs0, action, obs1, reward):
        # your code here
        raise NotImplemented